import 'package:hive_flutter/hive_flutter.dart';

late Box recentlyAccessedBox;
late Box trendingBox;
late Box networkCache;
late Box userCache;
