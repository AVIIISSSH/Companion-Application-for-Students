class UserConstants {
  static const userName = 'Companion User';
  static const userPhotoUrl = 'https://www.pngitem.com/pimgs/m/146-1468479_my-profile-icon-blank-profile-picture-circle-hd.png';
}