package com.lightheads.companion.companion

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
